from django.shortcuts import render
from rest_framework.viewsets import ModelViewSet
from .serializers import *
from rest_framework.generics import CreateAPIView
from django.contrib.auth.models import User
from rest_framework.viewsets import ModelViewSet
from .models import *
from rest_framework.permissions import IsAuthenticated
from django_filters import rest_framework as filters

# Create your views here.

class RegisterAPIView(CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer

class ToDoModelViewSet(ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = (filters.DjangoFilterBackend,)
    filterset_fields = {"completed" : ["exact"], "title" : ["icontains"], "description" :[ "icontains"], "created_at": ['gte', 'lte', 'date']}


    def get_queryset(self):
        user = self.request.user
        if user.is_authenticated:
            tasks = Task.objects.filter(owner=self.request.user)
            return tasks
        return Task.objects.none()
    
    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

    def perform_update(self, serializer):
        return serializer.save(owner=self.request.user)